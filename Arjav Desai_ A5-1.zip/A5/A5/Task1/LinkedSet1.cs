﻿using System;
using System.Collections;

namespace A5.Task1
{
	public class LinkedSet1 : ISet
	{
		private DoublyLinkedList data = new DoublyLinkedList();

		public bool add(int value)
		{
			// TODO Auto-generated method stub
			return false;
		}

		public void addMany(params int[] args)
		{
			// TODO Auto-generated method stub
		}

		public void addAll(ISet otherSet)
		{
			// TODO Auto-generated method stub
		}

		public bool remove(int value)
		{
			return false;
		}

		public bool contains(int target)
		{
			// TODO Auto-generated method stub
			return false;
		}

		public int get(int index)
		{
			// TODO Auto-generated method stub
			return -1;
		}

		public int size()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		public bool isEmpty()
		{
			// TODO Auto-generated method stub
			return false;
		}

		public void clear()
		{
			// TODO Auto-generated method stub
		}

		public String toString()
		{
			// TODO Auto-generated method stub
			return "";
		}

		public bool equals(Object other)
		{
			// todo auto-generated method stub
			return false;
		}
		public IEnumerator GetEnumerator()
		{
			throw new NotImplementedException();
		}
	}

}
