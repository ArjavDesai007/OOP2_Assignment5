﻿using System;

using A5.Task1;

namespace A5
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new DoublyLinkedList();

            list.AddFront(2);
            list.AddBack(3);
            list.AddFront(1);
            list.AddBack(4);

            for (int i = 0; i < 4; ++i)
            {
                Console.WriteLine(list.RemoveBack());
            }

            Console.WriteLine("Testing");

            var test = new int[10];
            test[0] = 1;

            foreach (var item in test)
            {
                Console.WriteLine(item);
            }
        }
    }
}
