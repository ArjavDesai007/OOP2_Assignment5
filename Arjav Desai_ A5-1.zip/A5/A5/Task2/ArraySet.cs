﻿namespace A5.Task2
{
	public class ArraySet<T> : ISet<T>
	{
		public bool add(T value)
		{
			// TODO Auto-generated method stub
			return false;
		}

		public void addMany(params T[] args )
		{
			// TODO Auto-generated method stub
		}

		public void addAll(ISet<T> otherSet)
		{
			// TODO Auto-generated method stub
		}

		public bool remove(T value)
		{
			// TODO Auto-generated method stub
			return false;
		}

		public bool contains(T target)
		{
			// TODO Auto-generated method stub
			return false;
		}

		public T get(int index)
		{
			// TODO Auto-generated method stub
			return default(T);
		}

		public int size()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		public bool isEmpty()
		{
			// TODO Auto-generated method stub
			return false;
		}

		public void clear()
		{
			// TODO Auto-generated method stub
		}

		public override string ToString()
		{
			// TODO Auto-generated method stub
			return "";
		}

		public bool equals(object other)
		{
			// TODO Auto-generated method stub
			return false;
		}
	}
}
